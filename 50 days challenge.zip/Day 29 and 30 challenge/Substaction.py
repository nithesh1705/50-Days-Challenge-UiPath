import os
def sub():
    result=25-10
    return result
