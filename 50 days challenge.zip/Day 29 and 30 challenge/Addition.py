import os

def add():
     result=25+10
     return result
